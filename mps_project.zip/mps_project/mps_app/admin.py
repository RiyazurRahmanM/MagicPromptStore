from django.contrib import admin
from .models import Prompts
# Register your models here.

admin.site.register(Prompts)